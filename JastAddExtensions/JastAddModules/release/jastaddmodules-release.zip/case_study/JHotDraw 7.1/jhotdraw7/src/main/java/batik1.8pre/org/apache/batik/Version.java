module org.apache.batik1_8pre;
package org.apache.batik;

public class Version {
	public static String version = "org.apache.batik v1.8pre";
}
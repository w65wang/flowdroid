module org.jhotdraw.batikfragment;
package org.apache.batik;

public class Version {
	public static String version = "org.jhotdraw batik";
}
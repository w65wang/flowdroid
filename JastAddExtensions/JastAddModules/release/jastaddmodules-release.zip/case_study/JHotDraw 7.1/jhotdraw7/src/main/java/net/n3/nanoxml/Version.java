package net.n3.nanoxml;

public class Version {
	public static final String version = "nanoxml 2_2_1_4patch";
}
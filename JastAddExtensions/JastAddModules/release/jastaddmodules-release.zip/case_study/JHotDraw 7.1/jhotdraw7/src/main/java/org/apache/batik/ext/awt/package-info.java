//module org.jhotdraw.batikfragment;
//package org.apache.batik.ext.awt;
module org.apache.batik1_6;
package org.apache.batik;

public class Version {
	public static String version = "org.apache.batik v1.6";
}
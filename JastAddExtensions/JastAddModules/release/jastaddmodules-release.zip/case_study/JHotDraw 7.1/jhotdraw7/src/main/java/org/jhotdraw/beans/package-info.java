module org.jhotdraw;
package org.jhotdraw.beans;